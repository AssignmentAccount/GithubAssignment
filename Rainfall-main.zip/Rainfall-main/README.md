# Rainfall
Repository on rainfall data for the github assignment

This repository is structured around the analysis of rainfall data from Melbourne and Oxford. This data has been stored within the data section, while the code was held within the source r code (scr) section. The first set of outputted data was then sorted into processedData and finally, was used in the production of the ouput of a resulting figure which was stored within the out section. This allows for clear distinctions between the specific elements and an additional distinction between intermediary and final outputs.
